<?php

/**
 * файл с описанием модуля, содержащий инсталлятор/деинсталлятор модуля.
 */
Class trustednet_auth extends CModule {

    var $MODULE_ID = "trustednet.auth";
    var $MODULE_NAME = "TrustedNet Auth";
    var $MODULE_DESCRIPTION = "Модуль аутентификации и авторизации пользователей TrustedNet Auth";
    var $MODULE_VERSION = "1.2.1";
    var $MODULE_VERSION_DATE = "2016.04.13";
    var $PARTNER_NAME = "ООО \"Цифровые технологии\"";
    var $PARTNER_URI = "http://www.digt.ru";

    function trustednet_auth() {
        $arModuleVersion = array();

        include(substr(__FILE__, 0, -10) . "/version.php");

        $this->MODULE_VERSION = $arModuleVersion["VERSION"];
        $this->MODULE_VERSION_DATE = $this->MODULE_VERSION_DATE;
        $this->MODULE_NAME = $this->MODULE_NAME;
        $this->MODULE_DESCRIPTION = $this->MODULE_DESCRIPTION;
        $this->PARTNER_NAME = $this->PARTNER_NAME;
        $this->PARTNER_URI = $this->PARTNER_URI;
    }

    function DoInstall() {
        global $DOCUMENT_ROOT, $APPLICATION;
        $this->InstallFiles();
        $this->InstallDB();
        $this->InstallEvents();
        RegisterModule($this->MODULE_ID);
        $APPLICATION->IncludeAdminFile(GetMessage("MOD_INSTALL_TITLE"), $DOCUMENT_ROOT . "/bitrix/modules/" . $this->MODULE_ID . "/install/step.php");
    }

    function DoUninstall() {
        global $DB, $APPLICATION, $step;
        $this->UnInstallFiles();
        $this->UnInstallDB();
        $this->UnInstallEvents();
        UnRegisterModule($this->MODULE_ID);
        $APPLICATION->IncludeAdminFile(GetMessage("MOD_INSTALL_TITLE"), $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/unstep.php");
    }

    function InstallDB() {
        global $DB;
        $sql = "CREATE TABLE IF NOT EXISTS `trn_user` (
                    `ID` int(11) NOT NULL,
                    `USER_ID` int(18) DEFAULT NULL,
                    `TIMESTAMP_X` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`ID`)
                    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        $DB->Query($sql);
    }

    function UnInstallDB() {
        global $DB;
        $sql = "DROP TABLE IF EXISTS `trn_user`";
        $DB->Query($sql);
    }

    function InstallFiles() {
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/components/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/components/", true, true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/admin", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin", true, false);
        return true;
    }

    function UnInstallFiles() {
        DeleteDirFilesEx("/bitrix/components/trustednet/" . $this->MODULE_ID);
        DeleteDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".$this->MODULE_ID."/install/admin/", $_SERVER["DOCUMENT_ROOT"]."/bitrix/admin");
        return true;
    }

}
