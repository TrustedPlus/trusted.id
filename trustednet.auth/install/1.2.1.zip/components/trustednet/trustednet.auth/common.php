<?php
require_once (__DIR__ . '/config.php');
require_once TRUSTED_MODULE_ROOT . '/trustednet.data/config.php';
require_once TRUSTED_MODULE_AUTH_ROOT . '/oauth2.php';