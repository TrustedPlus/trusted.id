<?php
/**
 * Авторизация через всплывающее окно
 */
require_once (__DIR__ . '/config.php');
require_once(TRUSTED_MODULE_AUTH);
include_once("./widget.tpl");