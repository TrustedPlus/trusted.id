<?php
/*
 * файл с номером версии модуля. Версия не может быть равной нулю.
 */
$arModuleVersion = array(
    "VERSION" => "1.2.1",
    "VERSION_DATE" => "2016.04.20"
);

